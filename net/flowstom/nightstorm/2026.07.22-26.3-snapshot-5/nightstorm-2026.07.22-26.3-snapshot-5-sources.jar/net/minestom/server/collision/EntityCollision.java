package net.minestom.server.collision;

import net.minestom.server.coordinate.Point;
import net.minestom.server.coordinate.Vec;
import net.minestom.server.entity.Entity;
import net.minestom.server.instance.EntityTracker;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

final class EntityCollision {
    static List<EntityCollisionResult> checkCollision(
            EntityTracker entityTracker,
            BoundingBox boundingBox, Point point, Vec entityVelocity,
            double extendRadius, Function<Entity, Boolean> entityFilter, @Nullable PhysicsResult physicsResult
    ) {
        double minimumRes = physicsResult != null ? physicsResult.res().res : Double.MAX_VALUE;

        List<EntityCollisionResult> result = new ArrayList<>();

        double maxDistance = Math.pow(boundingBox.height() * boundingBox.height() + boundingBox.depth() / 2 * boundingBox.depth() / 2 + boundingBox.width() / 2 * boundingBox.width() / 2, 1 / 3.0);
        double projectileDistance = entityVelocity.length();

        entityTracker.nearbyEntities(point, extendRadius + maxDistance + projectileDistance, EntityTracker.Target.ENTITIES, e -> {
            if (!entityFilter.apply(e)) return;
            if (!e.hasEntityCollision()) return;

            // Overlapping with entity, math can't be done we return the entity
            if (e.getBoundingBox().intersectBox(e.getPosition().sub(point), boundingBox)) {
                var p = point.asPos();
                result.add(new EntityCollisionResult(p, e, Vec.ZERO, 0));
                return;
            }

            // Check collisions with entity
            SweepResult sweepResult = new SweepResult(minimumRes, 0, 0, 0, null, 0, 0, 0, 0, 0, 0);
            boolean intersected = e.getBoundingBox().intersectBoxSwept(point, entityVelocity, e.getPosition(), boundingBox, sweepResult);

            if (intersected && sweepResult.res < 1) {
                var p = point.asPos().add(entityVelocity.mul(sweepResult.res));
                Vec direction = new Vec(sweepResult.collidedPositionX, sweepResult.collidedPositionY, sweepResult.collidedPositionZ);
                result.add(new EntityCollisionResult(p, e, direction, sweepResult.res));
            }
        });

        return result;
    }
}
