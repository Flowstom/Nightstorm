package net.minestom.server.entity.damage;

import net.minestom.server.codec.Codec;
import net.minestom.server.codec.StructCodec;
import net.minestom.server.network.NetworkBuffer;
import net.minestom.server.registry.BuiltinRegistries;
import net.minestom.server.registry.DynamicRegistry;
import net.minestom.server.registry.Registries;
import net.minestom.server.registry.RegistryKey;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

public sealed interface DamageType extends DamageTypes permits DamageTypeImpl {
    Codec<DamageType> REGISTRY_CODEC = StructCodec.struct(
            "message_id", Codec.STRING, DamageType::messageId,
            "scaling", Codec.STRING, DamageType::scaling,
            "exhaustion", Codec.FLOAT, DamageType::exhaustion,
            "effects", Codec.STRING.optional("hurt"), DamageType::effects,
            "death_message_type", Codec.STRING.optional("default"), DamageType::deathMessageType,
            DamageType::create);

    NetworkBuffer.Type<RegistryKey<DamageType>> NETWORK_TYPE = RegistryKey.networkType(Registries::damageType);
    Codec<RegistryKey<DamageType>> CODEC = RegistryKey.codec(Registries::damageType);

    static DamageType create(
            String messageId,
            String scaling,
            float exhaustion,
            @Nullable String effects,
            @Nullable String deathMessageType
    ) {
        return new DamageTypeImpl(messageId, scaling, exhaustion, effects, deathMessageType);
    }

    static Builder builder() {
        return new Builder();
    }

    /**
     * <p>Creates a new registry for damage types, loading the vanilla damage types.</p>
     *
     * @see net.minestom.server.MinecraftServer to get an existing instance of the registry
     */
    @ApiStatus.Internal
    static DynamicRegistry<DamageType> createDefaultRegistry() {
        return DynamicRegistry.create(BuiltinRegistries.DAMAGE_TYPE, REGISTRY_CODEC);
    }

    String messageId();

    String scaling();

    float exhaustion();

    @Nullable String effects();

    @Nullable String deathMessageType();

    final class Builder {
        private String messageId;
        private String scaling;
        private float exhaustion = 0f;
        private @Nullable String effects;
        private @Nullable String deathMessageType;

        private Builder() {
        }

        public Builder messageId(String messageId) {
            this.messageId = messageId;
            return this;
        }

        public Builder scaling(String scaling) {
            this.scaling = scaling;
            return this;
        }

        public Builder exhaustion(float exhaustion) {
            this.exhaustion = exhaustion;
            return this;
        }

        public Builder effects(@Nullable String effects) {
            this.effects = effects;
            return this;
        }

        public Builder deathMessageType(@Nullable String deathMessageType) {
            this.deathMessageType = deathMessageType;
            return this;
        }

        public DamageType build() {
            return new DamageTypeImpl(messageId, scaling, exhaustion, effects, deathMessageType);
        }
    }
}
