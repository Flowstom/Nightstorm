package net.minestom.server.entity.metadata.animal;

import net.minestom.server.component.DataComponent;
import net.minestom.server.component.DataComponents;
import net.minestom.server.entity.Entity;
import net.minestom.server.entity.MetadataDef;
import net.minestom.server.entity.MetadataHolder;
import net.minestom.server.registry.RegistryKey;
import org.jetbrains.annotations.Nullable;

public class PigMeta extends AnimalMeta {
    public PigMeta(@Nullable Entity entity, MetadataHolder metadata) {
        super(entity, metadata);
    }

    public int getTimeToBoost() {
        return metadata.get(MetadataDef.Pig.BOOST_TIME);
    }

    public void setTimeToBoost(int value) {
        metadata.set(MetadataDef.Pig.BOOST_TIME, value);
    }

    /**
     * @deprecated use {@link net.minestom.server.component.DataComponents#PIG_VARIANT} instead.
     */
    @Deprecated
    public RegistryKey<PigVariant> getVariant() {
        return metadata.get(MetadataDef.Pig.VARIANT);
    }

    /**
     * @deprecated use {@link net.minestom.server.component.DataComponents#PIG_VARIANT} instead.
     */
    @Deprecated
    public void setVariant(RegistryKey<PigVariant> value) {
        metadata.set(MetadataDef.Pig.VARIANT, value);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected <T> @Nullable T get(DataComponent<T> component) {
        if (component == DataComponents.PIG_VARIANT)
            return (T) getVariant();
        if (component == DataComponents.PIG_SOUND_VARIANT)
            return (T) metadata.get(MetadataDef.Pig.SOUND_VARIANT);
        return super.get(component);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected <T> void set(DataComponent<T> component, T value) {
        if (component == DataComponents.PIG_VARIANT)
            setVariant((RegistryKey<PigVariant>) value);
        else if (component == DataComponents.PIG_SOUND_VARIANT)
            metadata.set(MetadataDef.Pig.SOUND_VARIANT, (RegistryKey<PigSoundVariant>) value);
        else super.set(component, value);
    }

}
