package net.minestom.server.entity.metadata.water.fish;

import net.minestom.server.entity.Entity;
import net.minestom.server.entity.MetadataHolder;
import org.jetbrains.annotations.Nullable;

public class CodMeta extends AbstractFishMeta {
    public CodMeta(@Nullable Entity entity, MetadataHolder metadata) {
        super(entity, metadata);
    }

}
