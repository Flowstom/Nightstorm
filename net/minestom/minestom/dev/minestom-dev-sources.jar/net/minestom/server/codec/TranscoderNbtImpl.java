package net.minestom.server.codec;

import net.kyori.adventure.nbt.BinaryTag;
import net.kyori.adventure.nbt.ByteArrayBinaryTag;
import net.kyori.adventure.nbt.ByteBinaryTag;
import net.kyori.adventure.nbt.CompoundBinaryTag;
import net.kyori.adventure.nbt.DoubleBinaryTag;
import net.kyori.adventure.nbt.EndBinaryTag;
import net.kyori.adventure.nbt.FloatBinaryTag;
import net.kyori.adventure.nbt.IntArrayBinaryTag;
import net.kyori.adventure.nbt.IntBinaryTag;
import net.kyori.adventure.nbt.ListBinaryTag;
import net.kyori.adventure.nbt.LongArrayBinaryTag;
import net.kyori.adventure.nbt.LongBinaryTag;
import net.kyori.adventure.nbt.NumberBinaryTag;
import net.kyori.adventure.nbt.ShortBinaryTag;
import net.kyori.adventure.nbt.StringBinaryTag;
import org.jetbrains.annotations.ApiStatus;

import java.util.AbstractList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@ApiStatus.Internal
final class TranscoderNbtImpl implements Transcoder<BinaryTag> {
    static final TranscoderNbtImpl INSTANCE = new TranscoderNbtImpl();
    private static final int MAX_DIAGNOSTIC_LENGTH = 64;

    @Override
    public BinaryTag createNull() {
        return EndBinaryTag.endBinaryTag();
    }

    @Override
    public Result<Boolean> getBoolean(BinaryTag value) {
        return value instanceof NumberBinaryTag number
                ? new Result.Ok<>(number.byteValue() != 0)
                : typeMismatch("boolean", value);
    }

    @Override
    public BinaryTag createBoolean(boolean value) {
        return value ? ByteBinaryTag.ONE : ByteBinaryTag.ZERO;
    }

    @Override
    public Result<Byte> getByte(BinaryTag value) {
        return value instanceof NumberBinaryTag number
                ? new Result.Ok<>(number.byteValue())
                : typeMismatch("byte", value);
    }

    @Override
    public BinaryTag createByte(byte value) {
        if (value == 0) return ByteBinaryTag.ZERO;
        if (value == 1) return ByteBinaryTag.ONE;
        return ByteBinaryTag.byteBinaryTag(value);
    }

    @Override
    public Result<Short> getShort(BinaryTag value) {
        return value instanceof NumberBinaryTag number
                ? new Result.Ok<>(number.shortValue())
                : typeMismatch("short", value);
    }

    @Override
    public BinaryTag createShort(short value) {
        return ShortBinaryTag.shortBinaryTag(value);
    }

    @Override
    public Result<Integer> getInt(BinaryTag value) {
        return value instanceof NumberBinaryTag number
                ? new Result.Ok<>(number.intValue())
                : typeMismatch("int", value);
    }

    @Override
    public BinaryTag createInt(int value) {
        return IntBinaryTag.intBinaryTag(value);
    }

    @Override
    public Result<Long> getLong(BinaryTag value) {
        return value instanceof NumberBinaryTag number
                ? new Result.Ok<>(number.longValue())
                : typeMismatch("long", value);
    }

    @Override
    public BinaryTag createLong(long value) {
        return LongBinaryTag.longBinaryTag(value);
    }

    @Override
    public Result<Float> getFloat(BinaryTag value) {
        return value instanceof NumberBinaryTag number
                ? new Result.Ok<>(number.floatValue())
                : typeMismatch("float", value);
    }

    @Override
    public BinaryTag createFloat(float value) {
        return FloatBinaryTag.floatBinaryTag(value);
    }

    @Override
    public Result<Double> getDouble(BinaryTag value) {
        return value instanceof NumberBinaryTag number
                ? new Result.Ok<>(number.doubleValue())
                : typeMismatch("double", value);
    }

    @Override
    public BinaryTag createDouble(double value) {
        return DoubleBinaryTag.doubleBinaryTag(value);
    }

    @Override
    public Result<Number> getNumber(BinaryTag value) {
        return value instanceof NumberBinaryTag number
                ? new Result.Ok<>(number.numberValue())
                : typeMismatch("number", value);
    }

    @Override
    public Result<String> getString(BinaryTag value) {
        return value instanceof StringBinaryTag string
                ? new Result.Ok<>(string.value())
                : typeMismatch("string", value);
    }

    @Override
    public BinaryTag createString(String value) {
        return StringBinaryTag.stringBinaryTag(value);
    }

    @Override
    public Result<List<BinaryTag>> getList(BinaryTag value) {
        if (!(value instanceof ListBinaryTag listTagWrapped))
            return typeMismatch("list", value);
        final ListBinaryTag listTag = listTagWrapped.unwrapHeterogeneity();
        return new Result.Ok<>(new AbstractList<>() {
            @Override
            public BinaryTag get(int index) {
                return listTag.get(index);
            }

            @Override
            public int size() {
                return listTag.size();
            }
        });
    }

    @Override
    public BinaryTag emptyList() {
        return ListBinaryTag.empty();
    }

    @Override
    public ListBuilder<BinaryTag> createList(int expectedSize) {
        final ListBinaryTag.Builder<BinaryTag> elements = ListBinaryTag.heterogeneousListBinaryTag();
        return new ListBuilder<>() {
            @Override
            public ListBuilder<BinaryTag> add(BinaryTag value) {
                elements.add(value);
                return this;
            }

            @Override
            public BinaryTag build() {
                return elements.build();
            }
        };
    }

    @Override
    public Result<MapLike<BinaryTag>> getMap(BinaryTag value) {
        if (!(value instanceof CompoundBinaryTag compoundTag))
            return typeMismatch("compound", value);
        return new Result.Ok<>(new MapLike<>() {
            @Override
            public Set<String> keys() {
                return compoundTag.keySet();
            }

            @Override
            public boolean hasValue(String key) {
                return compoundTag.get(key) != null;
            }

            @Override
            public Result<BinaryTag> getValue(String key) {
                final BinaryTag tag = compoundTag.get(key);
                if (tag == null) return new Result.Error<>("No such key: " + key);
                return new Result.Ok<>(tag);
            }

            @Override
            public int size() {
                return compoundTag.size();
            }
        });
    }

    @Override
    public BinaryTag emptyMap() {
        return CompoundBinaryTag.empty();
    }

    @Override
    public MapBuilder<BinaryTag> createMap() {
        final CompoundBinaryTag.Builder builder = CompoundBinaryTag.builder();
        return new MapBuilder<>() {
            @Override
            public MapBuilder<BinaryTag> put(BinaryTag key, BinaryTag value) {
                if (!(value instanceof EndBinaryTag) && key instanceof StringBinaryTag string)
                    builder.put(string.value(), value);
                return this;
            }

            @Override
            public MapBuilder<BinaryTag> put(String key, BinaryTag value) {
                if (!(value instanceof EndBinaryTag))
                    builder.put(key, value);
                return this;
            }

            @Override
            public BinaryTag build() {
                return builder.build();
            }
        };
    }

    @Override
    public Result<byte[]> getByteArray(BinaryTag value) {
        return value instanceof ByteArrayBinaryTag byteArray
                ? new Result.Ok<>(byteArray.value())
                : Transcoder.super.getByteArray(value);
    }

    @Override
    public BinaryTag createByteArray(byte[] value) {
        return ByteArrayBinaryTag.byteArrayBinaryTag(value);
    }

    @Override
    public Result<int[]> getIntArray(BinaryTag value) {
        return value instanceof IntArrayBinaryTag intArray
                ? new Result.Ok<>(intArray.value())
                : Transcoder.super.getIntArray(value);
    }

    @Override
    public BinaryTag createIntArray(int[] value) {
        return IntArrayBinaryTag.intArrayBinaryTag(value);
    }

    @Override
    public Result<long[]> getLongArray(BinaryTag value) {
        return value instanceof LongArrayBinaryTag longArray
                ? new Result.Ok<>(longArray.value())
                : Transcoder.super.getLongArray(value);
    }

    @Override
    public BinaryTag createLongArray(long[] value) {
        return LongArrayBinaryTag.longArrayBinaryTag(value);
    }

    @Override
    public <O> Result<O> convertTo(Transcoder<O> coder, BinaryTag value) {
        return switch (value) {
            case EndBinaryTag _ -> new Result.Ok<>(coder.createNull());
            case ByteBinaryTag byteTag -> new Result.Ok<>(coder.createByte(byteTag.byteValue()));
            case ShortBinaryTag shortTag -> new Result.Ok<>(coder.createShort(shortTag.shortValue()));
            case IntBinaryTag intTag -> new Result.Ok<>(coder.createInt(intTag.intValue()));
            case LongBinaryTag longTag -> new Result.Ok<>(coder.createLong(longTag.longValue()));
            case FloatBinaryTag floatTag -> new Result.Ok<>(coder.createFloat(floatTag.floatValue()));
            case DoubleBinaryTag doubleTag -> new Result.Ok<>(coder.createDouble(doubleTag.doubleValue()));
            case ByteArrayBinaryTag byteArrayTag -> new Result.Ok<>(coder.createByteArray(byteArrayTag.value()));
            case StringBinaryTag stringTag -> new Result.Ok<>(coder.createString(stringTag.value()));
            case ListBinaryTag listTag -> {
                listTag = listTag.unwrapHeterogeneity();
                final ListBuilder<O> list = coder.createList(listTag.size());
                for (int i = 0; i < listTag.size(); i++) {
                    switch (convertTo(coder, listTag.get(i))) {
                        case Result.Ok<O> ok -> list.add(ok.value());
                        case Result.Error<O> error -> {
                            yield new Result.Error<>(i + ": " + error);
                        }
                    }
                }
                yield new Result.Ok<>(list.build());
            }
            case CompoundBinaryTag compoundTag -> {
                final MapBuilder<O> map = coder.createMap();
                for (Map.Entry<String, ? extends BinaryTag> entry : compoundTag) {
                    switch (convertTo(coder, entry.getValue())) {
                        case Result.Ok<O> ok -> map.put(coder.createString(entry.getKey()), ok.value());
                        case Result.Error<O> error -> {
                            yield new Result.Error<>(entry.getKey() + ": " + error);
                        }
                    }
                }
                yield new Result.Ok<>(map.build());
            }
            case IntArrayBinaryTag intArrayTag -> new Result.Ok<>(coder.createIntArray(intArrayTag.value()));
            case LongArrayBinaryTag longArrayTag -> new Result.Ok<>(coder.createLongArray(longArrayTag.value()));
            default -> new Result.Error<>("Unsupported NBT type: " + describe(value));
        };
    }

    private static <T> Result.Error<T> typeMismatch(String expected, BinaryTag value) {
        return new Result.Error<>("Expected " + expected + " NBT, found " + describe(value));
    }

    // Tags may come from clients, so never render more than a bounded preview
    private static String describe(BinaryTag value) {
        final String preview = switch (value) {
            case NumberBinaryTag number -> String.valueOf(number.numberValue());
            case StringBinaryTag string -> string.value().length() > MAX_DIAGNOSTIC_LENGTH
                    ? '"' + string.value().substring(0, MAX_DIAGNOSTIC_LENGTH) + "\"..."
                    : '"' + string.value() + '"';
            case CompoundBinaryTag compound -> "{" + compound.size() + " entries}";
            case ListBinaryTag list -> "[" + list.size() + " entries]";
            case ByteArrayBinaryTag array -> "[B; " + array.size() + " entries]";
            case IntArrayBinaryTag array -> "[I; " + array.size() + " entries]";
            case LongArrayBinaryTag array -> "[L; " + array.size() + " entries]";
            default -> "";
        };
        return preview.isEmpty() ? value.type().toString() : value.type() + " " + preview;
    }
}
