package net.minestom.server.collision;

import net.minestom.server.coordinate.BlockVec;
import net.minestom.server.coordinate.Point;
import net.minestom.server.coordinate.Pos;
import net.minestom.server.coordinate.Vec;
import net.minestom.server.entity.Entity;
import net.minestom.server.entity.Player;
import net.minestom.server.instance.Instance;
import net.minestom.server.instance.WorldBorder;
import net.minestom.server.instance.block.Block;
import org.jetbrains.annotations.Nullable;

final class BlockCollision {
    static final @Nullable Vec[] NO_COLLISION_POINTS = new Vec[3];
    static final @Nullable Shape[] NO_COLLISION_SHAPES = new Shape[3];
    static final @Nullable BlockVec[] NO_COLLISION_SHAPE_POSITIONS = new BlockVec[3];

    /**
     * Moves an entity with physics applied (ie checking against blocks)
     * <p>
     * Works by getting all the full blocks that an entity could interact with.
     * All bounding boxes inside the full blocks are checked for collisions with the entity.
     */
    static PhysicsResult handlePhysics(BoundingBox boundingBox,
                                       Vec velocity, Pos entityPosition,
                                       Block.Getter getter,
                                       @Nullable PhysicsResult lastPhysicsResult,
                                       boolean singleCollision) {
        return handlePhysics(boundingBox, velocity, entityPosition, getter, lastPhysicsResult, singleCollision, null);
    }

    static PhysicsResult handlePhysics(BoundingBox boundingBox,
                                       Vec velocity, Pos entityPosition,
                                       Block.Getter getter,
                                       @Nullable PhysicsResult lastPhysicsResult,
                                       boolean singleCollision,
                                       @Nullable WorldBorder worldBorder) {
        if (velocity.isZero()) {
            return new PhysicsResult(entityPosition, Vec.ZERO, false, false, false, false,
                    velocity, NO_COLLISION_POINTS, NO_COLLISION_SHAPES, NO_COLLISION_SHAPE_POSITIONS, false, Double.MAX_VALUE);
        }
        // Fast-exit using cache
        final PhysicsResult cachedResult = cachedPhysics(velocity, entityPosition, getter, lastPhysicsResult);
        if (cachedResult != null) {
            return cachedResult;
        }
        // Expensive AABB computation
        return stepPhysics(boundingBox, velocity, entityPosition, getter, singleCollision, worldBorder);
    }

    @Nullable
    static Entity canPlaceBlockAt(Instance instance, Point blockPos, Block b) {
        for (Entity entity : instance.getNearbyEntities(blockPos, 3)) {
            if (!entity.preventBlockPlacement())
                continue;

            final boolean intersects;
            if (entity instanceof Player) {
                // Need to move player slightly away from block we're placing.
                // If player is at block 40 we cannot place a block at block 39 with side length 1 because the block will be in [39, 40]
                // For this reason we subtract a small amount from the player position
                Point playerPos = entity.getPosition().add(entity.getPosition().sub(blockPos).mul(0.0000001));
                intersects = b.collisionShape().intersectBox(playerPos.sub(blockPos), entity.getBoundingBox());
            } else {
                intersects = b.collisionShape()
                        .intersectBox(entity.getPosition().sub(blockPos), entity.getBoundingBox());
            }
            if (intersects) return entity;
        }
        return null;
    }

    @Nullable
    private static PhysicsResult cachedPhysics(Vec velocity, Pos entityPosition,
                                               Block.Getter getter, @Nullable PhysicsResult lastPhysicsResult) {
        if (lastPhysicsResult == null
                || !lastPhysicsResult.collisionY()
                || velocity.x() != 0 || velocity.z() != 0
                || !velocity.samePoint(lastPhysicsResult.originalDelta())
                || !entityPosition.samePoint(lastPhysicsResult.newPosition())) {
            return null;
        }

        if (!(lastPhysicsResult.collisionShapes()[1] instanceof ShapeImpl lastShape)) return null;
        final @Nullable BlockVec blockPosition = lastPhysicsResult.collisionShapePositions()[1];
        assert blockPosition != null;

        final var lastBlockBoxes = lastShape.boundingBoxes();
        if (lastBlockBoxes.isEmpty()) return null;

        // Reuse an identical vertical collision while the supporting shape is unchanged.
        final Shape currentShape = getter.getBlock(blockPosition, Block.Getter.Condition.TYPE).collisionShape();
        return currentShape instanceof ShapeImpl shape && shape.boundingBoxes().equals(lastBlockBoxes)
                ? lastPhysicsResult : null;
    }

    private static PhysicsResult stepPhysics(BoundingBox boundingBox,
                                             Vec velocity, Pos entityPosition,
                                             Block.Getter getter, boolean singleCollision,
                                             @Nullable WorldBorder worldBorder) {
        final SweepResult finalResult = new SweepResult(1 - Vec.EPSILON, 0, 0, 0, null, 0, 0, 0, 0, 0, 0);

        // Start as the shared (all-null) arrays; only allocate real ones on the first collision.
        @Nullable Vec[] collidedPoints = NO_COLLISION_POINTS;
        @Nullable Shape[] collisionShapes = NO_COLLISION_SHAPES;
        @Nullable BlockVec[] collisionShapePositions = NO_COLLISION_SHAPE_POSITIONS;

        // The world border acts as four vertical walls around the complete bounding box.
        double borderMinX = 0, borderMaxX = 0, borderMinZ = 0, borderMaxZ = 0;
        boolean sweepBorder = false;
        if (worldBorder != null) {
            final double radius = worldBorder.diameter() / 2;
            final double wallMinX = Math.floor(worldBorder.centerX() - radius);
            final double wallMaxX = Math.ceil(worldBorder.centerX() + radius);
            final double wallMinZ = Math.floor(worldBorder.centerZ() - radius);
            final double wallMaxZ = Math.ceil(worldBorder.centerZ() + radius);
            borderMinX = wallMinX - boundingBox.minX();
            borderMaxX = wallMaxX - boundingBox.maxX();
            borderMinZ = wallMinZ - boundingBox.minZ();
            borderMaxZ = wallMaxZ - boundingBox.maxZ();
            // The border only collides entities inside it, with a margin of the bounding
            // box size (at least one block). Entities farther outside move freely.
            final double margin = Math.max(Math.max(boundingBox.width(), boundingBox.depth()), 1);
            final double targetX = entityPosition.x() + velocity.x();
            final double targetZ = entityPosition.z() + velocity.z();
            sweepBorder = (targetX < borderMinX || targetX > borderMaxX || targetZ < borderMinZ || targetZ > borderMaxZ)
                    && entityPosition.x() >= wallMinX - margin && entityPosition.x() < wallMaxX + margin
                    && entityPosition.z() >= wallMinZ - margin && entityPosition.z() < wallMaxZ + margin;
        }

        Pos position = entityPosition;
        Vec remaining = velocity;
        boolean foundX = false;
        boolean foundY = false;
        boolean foundZ = false;
        // Each sweep advances along `remaining` until the first hit, zeroes the
        // collided axis, then repeats so the entity slides along the others.
        while (true) {
            if (sweepBorder) {
                sweepWorldBorderAxis(position.x(), remaining.x(),
                        borderMinX, borderMaxX, 0,
                        position, remaining, finalResult);
                sweepWorldBorderAxis(position.z(), remaining.z(),
                        borderMinZ, borderMaxZ, 2,
                        position, remaining, finalResult);
            }
            sweepBlocks(boundingBox, remaining, position, getter, finalResult);
            final double res = finalResult.res;
            double dx = res * remaining.x();
            double dy = res * remaining.y();
            double dz = res * remaining.z();
            if (Math.abs(dx) < Vec.EPSILON) dx = 0;
            if (Math.abs(dy) < Vec.EPSILON) dy = 0;
            if (Math.abs(dz) < Vec.EPSILON) dz = 0;
            position = position.add(dx, dy, dz);

            // The slab method records the entry face as a single non-zero normal.
            final int axis;
            if (finalResult.normalX != 0) axis = 0;
            else if (finalResult.normalY != 0) axis = 1;
            else if (finalResult.normalZ != 0) axis = 2;
            else break; // no collision this pass

            if (axis == 0) foundX = true;
            else if (axis == 1) foundY = true;
            else foundZ = true;

            if (collidedPoints == NO_COLLISION_POINTS) {
                collidedPoints = new Vec[3];
            }
            collidedPoints[axis] = new Vec(finalResult.collidedPositionX, finalResult.collidedPositionY, finalResult.collidedPositionZ);
            // World border collisions have a point and axis, but no block shape or position.
            final Shape collidedShape = finalResult.collidedShape;
            if (collidedShape != null) {
                if (collisionShapes == NO_COLLISION_SHAPES) {
                    collisionShapes = new Shape[3];
                    collisionShapePositions = new BlockVec[3];
                }
                collisionShapes[axis] = collidedShape;
                collisionShapePositions[axis] = new BlockVec(finalResult.collidedBlockX, finalResult.collidedBlockY, finalResult.collidedBlockZ);
            }

            if (singleCollision || (foundX && foundY && foundZ))
                break;

            remaining = new Vec(
                    axis == 0 ? 0 : remaining.x() - dx,
                    axis == 1 ? 0 : remaining.y() - dy,
                    axis == 2 ? 0 : remaining.z() - dz);
            if (remaining.isZero()) break;

            finalResult.normalX = 0;
            finalResult.normalY = 0;
            finalResult.normalZ = 0;
            finalResult.res = 1 - Vec.EPSILON;
        }

        final boolean anyCollision = foundX || foundY || foundZ;
        final boolean allCollision = foundX && foundY && foundZ;
        final Vec newDelta;
        if (!anyCollision) {
            newDelta = velocity;
        } else if (allCollision) {
            newDelta = Vec.ZERO;
        } else {
            newDelta = new Vec(foundX ? 0 : velocity.x(), foundY ? 0 : velocity.y(), foundZ ? 0 : velocity.z());
        }
        return new PhysicsResult(position, newDelta,
                foundY && velocity.y() < 0,
                foundX, foundY, foundZ,
                velocity, collidedPoints, collisionShapes, collisionShapePositions,
                anyCollision, finalResult.res);
    }

    /**
     * Sweeps against one pair of world border walls, located entity-relative at {@code minimum}
     * and {@code maximum}. A wall only stops a box that has not yet crossed it. A box already
     * extending past a wall keeps moving away from the border freely.
     */
    private static void sweepWorldBorderAxis(double position, double velocity,
                                             double minimum, double maximum, int axis,
                                             Pos entityPosition, Vec entityVelocity,
                                             SweepResult finalResult) {
        final double percentage;
        if (velocity > 0) {
            if (position > maximum || position + velocity <= maximum) return;
            percentage = (maximum - position) / velocity;
        } else if (velocity < 0) {
            if (position < minimum || position + velocity >= minimum) return;
            percentage = (minimum - position) / velocity;
        } else {
            return;
        }

        final double acceptedPercentage = percentage * 0.99999;
        if (!(acceptedPercentage <= finalResult.res)) return;

        finalResult.res = acceptedPercentage;
        finalResult.normalX = axis == 0 ? 1 : 0;
        finalResult.normalY = 0;
        finalResult.normalZ = axis == 2 ? 1 : 0;
        finalResult.collidedPositionX = entityPosition.x() + entityVelocity.x() * acceptedPercentage;
        finalResult.collidedPositionY = entityPosition.y() + entityVelocity.y() * acceptedPercentage;
        finalResult.collidedPositionZ = entityPosition.z() + entityVelocity.z() * acceptedPercentage;
        finalResult.collidedShape = null;
    }

    /**
     * Iterate the blocks overlapping the swept bounding box (start -> start+velocity), near-to-far
     * along the movement so {@code finalResult.res} tightens early and farther blocks are rejected
     * cheaply by the SweepResult distance gate. Each block is visited exactly once.
     */
    private static void sweepBlocks(BoundingBox boundingBox,
                                    Vec velocity, Pos entityPosition,
                                    Block.Getter getter,
                                    SweepResult finalResult) {
        final double startX = entityPosition.x();
        final double startY = entityPosition.y();
        final double startZ = entityPosition.z();
        final double endX = startX + velocity.x();
        final double endY = startY + velocity.y();
        final double endZ = startZ + velocity.z();

        // Block-aligned bounds of the swept AABB.
        final int minX = (int) Math.floor(Math.min(startX, endX) + boundingBox.minX());
        final int minY = (int) Math.floor(Math.min(startY, endY) + boundingBox.minY());
        final int minZ = (int) Math.floor(Math.min(startZ, endZ) + boundingBox.minZ());
        final int maxX = (int) Math.floor(Math.max(startX, endX) + boundingBox.maxX());
        final int maxY = (int) Math.floor(Math.max(startY, endY) + boundingBox.maxY());
        final int maxZ = (int) Math.floor(Math.max(startZ, endZ) + boundingBox.maxZ());

        // Walk from near to far along velocity.
        final int stepX = velocity.x() < 0 ? -1 : 1;
        final int stepY = velocity.y() < 0 ? -1 : 1;
        final int stepZ = velocity.z() < 0 ? -1 : 1;
        final int firstX = stepX > 0 ? minX : maxX, lastX = stepX > 0 ? maxX : minX;
        final int firstY = stepY > 0 ? minY : maxY, lastY = stepY > 0 ? maxY : minY;
        final int firstZ = stepZ > 0 ? minZ : maxZ, lastZ = stepZ > 0 ? maxZ : minZ;

        for (int x = firstX; x != lastX + stepX; x += stepX) {
            for (int y = firstY; y != lastY + stepY; y += stepY) {
                for (int z = firstZ; z != lastZ + stepZ; z += stepZ) {
                    checkBoundingBox(x, y, z, velocity, entityPosition, boundingBox, getter, finalResult);
                }
            }
        }
    }

    /**
     * Check if a moving entity will collide with a block. Updates finalResult
     *
     * @param blockX         block x position
     * @param blockY         block y position
     * @param blockZ         block z position
     * @param entityVelocity entity movement vector
     * @param entityPosition entity position
     * @param boundingBox    entity bounding box
     * @param getter         block getter
     * @param finalResult    place to store final result of collision
     * @return true if entity finds collision, other false
     */
    static boolean checkBoundingBox(int blockX, int blockY, int blockZ,
                                    Vec entityVelocity, Pos entityPosition, BoundingBox boundingBox,
                                    Block.Getter getter, SweepResult finalResult) {
        // Don't step if chunk isn't loaded yet
        final Block currentBlock = getter.getBlock(blockX, blockY, blockZ, Block.Getter.Condition.TYPE);
        final Shape currentShape = currentBlock.collisionShape();

        final boolean currentCollidable = !currentShape.relativeEnd().isZero();
        final boolean currentShort = currentShape.relativeEnd().y() < 0.5;

        // only consider the block below if our current shape is sufficiently short
        if (currentShort && shouldCheckLower(entityVelocity, entityPosition, blockX, blockY, blockZ)) {
            // we need to check below for a tall block (fence, wall, ...)
            final BlockVec belowPos = new BlockVec(blockX, blockY - 1, blockZ);
            final Block belowBlock = getter.getBlock(belowPos, Block.Getter.Condition.TYPE);
            final Shape belowShape = belowBlock.collisionShape();

            final BlockVec currentPos = new BlockVec(blockX, blockY, blockZ);
            // don't fall out of if statement, we could end up redundantly grabbing a block, and we only need to
            // collision check against the current shape since the below shape isn't tall
            if (belowShape.relativeEnd().y() > 1) {
                // we should always check both shapes, to handle properties where the bounding box
                // hits the current solid but misses the tall solid
                final boolean belowHit = belowShape.intersectBoxSwept(entityPosition, entityVelocity, belowPos, boundingBox, finalResult);
                final boolean currentHit = currentCollidable && currentShape.intersectBoxSwept(entityPosition, entityVelocity, currentPos, boundingBox, finalResult);
                return belowHit || currentHit;
            } else {
                return currentCollidable && currentShape.intersectBoxSwept(entityPosition, entityVelocity, currentPos, boundingBox, finalResult);
            }
        }

        if (currentCollidable && currentShape.intersectBoxSwept(entityPosition, entityVelocity,
                new BlockVec(blockX, blockY, blockZ), boundingBox, finalResult)) {
            // if the current collision is sufficiently short, we might need to collide against the block below too
            if (currentShort) {
                final BlockVec belowPos = new BlockVec(blockX, blockY - 1, blockZ);
                final Block belowBlock = getter.getBlock(belowPos, Block.Getter.Condition.TYPE);
                final Shape belowShape = belowBlock.collisionShape();
                // only do sweep if the below block is big enough to possibly hit
                if (belowShape.relativeEnd().y() > 1)
                    belowShape.intersectBoxSwept(entityPosition, entityVelocity, belowPos, boundingBox, finalResult);
            }
            return true;
        }
        return false;
    }

    private static boolean shouldCheckLower(Vec entityVelocity, Pos entityPosition, int blockX, int blockY, int blockZ) {
        final double yVelocity = entityVelocity.y();
        // if moving horizontally, just check if the floor of the entity's position is the same as the blockY
        if (yVelocity == 0) return Math.floor(entityPosition.y()) == blockY;
        final double xVelocity = entityVelocity.x();
        final double zVelocity = entityVelocity.z();
        // if moving straight up, don't bother checking for tall solids beneath anything
        // if moving straight down, only check for a tall solid underneath the last block
        if (xVelocity == 0 && zVelocity == 0)
            return yVelocity < 0 && blockY == Math.floor(entityPosition.y() + yVelocity);
        // default to true: if no x velocity, only consider YZ line, and vice-versa
        final boolean underYX = xVelocity != 0 && computeHeight(yVelocity, xVelocity, entityPosition.y(), entityPosition.x(), blockX) >= blockY;
        final boolean underYZ = zVelocity != 0 && computeHeight(yVelocity, zVelocity, entityPosition.y(), entityPosition.z(), blockZ) >= blockY;
        // true if the block is at or below the same height as a line drawn from the entity's position to its final
        // destination
        return underYX && underYZ;
    }

    /*
    computes the height of the entity at the given block position along a projection of the line it's travelling along
    (YX or YZ). the returned value will be greater than or equal to the block height if the block is along the lower
    layer of intersections with this line.
     */
    private static double computeHeight(double yVelocity, double velocity, double entityY, double pos, int blockPos) {
        final double m = yVelocity / velocity;
        /*
        offsetting by 1 is necessary with a positive slope, because we can clip the bottom-right corner of blocks
        without clipping the "bottom-left" (the smallest corner of the block on the YZ or YX plane). without the offset
        these would not be considered to be on the lowest layer, since our block position represents the bottom-left
        corner
         */
        return m * (blockPos - pos + (m > 0 ? 1 : 0)) + entityY;
    }
}
