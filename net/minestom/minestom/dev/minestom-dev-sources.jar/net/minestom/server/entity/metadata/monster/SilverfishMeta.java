package net.minestom.server.entity.metadata.monster;

import net.minestom.server.entity.Entity;
import net.minestom.server.entity.MetadataHolder;
import org.jetbrains.annotations.Nullable;

public class SilverfishMeta extends MonsterMeta {
    public SilverfishMeta(@Nullable Entity entity, MetadataHolder metadata) {
        super(entity, metadata);
    }

}
