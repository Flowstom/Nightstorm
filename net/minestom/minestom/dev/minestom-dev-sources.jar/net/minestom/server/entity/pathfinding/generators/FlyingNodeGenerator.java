package net.minestom.server.entity.pathfinding.generators;

import net.minestom.server.collision.BoundingBox;
import net.minestom.server.coordinate.Point;
import net.minestom.server.coordinate.Vec;
import net.minestom.server.entity.pathfinding.PNode;
import net.minestom.server.instance.block.Block;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.OptionalDouble;
import java.util.Set;

public class FlyingNodeGenerator implements NodeGenerator {
    private @Nullable PNode tempNode = null;

    @Override
    public Collection<? extends PNode> getWalkable(Block.Getter getter, Set<PNode> visited, PNode current, Point goal, BoundingBox boundingBox) {
        List<PNode> nearby = new ArrayList<>();
        tempNode = new PNode(0, 0, 0, 0, 0, current);

        int stepSize = (int) Math.max(Math.floor(boundingBox.width() / 2), 1);
        if (stepSize < 1) stepSize = 1;

        for (int x = -stepSize; x <= stepSize; ++x) {
            for (int z = -stepSize; z <= stepSize; ++z) {
                if (x == 0 && z == 0) continue;
                double cost = Math.sqrt(x * x + z * z) * 0.98;

                double currentLevelPointX = current.blockX() + 0.5 + x;
                double currentLevelPointY = current.blockY() + 0.5;
                double currentLevelPointZ = current.blockZ() + 0.5 + z;

                double upPointX = current.blockX() + 0.5 + x;
                double upPointY = current.blockY() + 1 + 0.5;
                double upPointZ = current.blockZ() + 0.5 + z;

                double downPointX = current.blockX() + 0.5 + x;
                double downPointY = current.blockY() - 1 + 0.5;
                double downPointZ = current.blockZ() + 0.5 + z;

                var nodeWalk = createFly(getter, new Vec(currentLevelPointX, currentLevelPointY, currentLevelPointZ), boundingBox, cost, current, goal, visited);
                if (nodeWalk != null && !visited.contains(nodeWalk)) nearby.add(nodeWalk);

                var nodeJump = createFly(getter, new Vec(upPointX, upPointY, upPointZ), boundingBox, cost, current, goal, visited);
                if (nodeJump != null && !visited.contains(nodeJump)) nearby.add(nodeJump);

                var nodeFall = createFly(getter, new Vec(downPointX, downPointY, downPointZ), boundingBox, cost, current, goal, visited);
                if (nodeFall != null && !visited.contains(nodeFall)) nearby.add(nodeFall);
            }
        }

        // Straight up
        double upPointX = current.x();
        double upPointY = current.blockY() + 1 + 0.5;
        double upPointZ = current.z();

        var nodeJump = createFly(getter, new Vec(upPointX, upPointY, upPointZ), boundingBox, 2, current, goal, visited);
        if (nodeJump != null && !visited.contains(nodeJump)) nearby.add(nodeJump);

        // Straight down
        double downPointX = current.x();
        double downPointY = current.blockY() - 1 + 0.5;
        double downPointZ = current.z();

        var nodeFall = createFly(getter, new Vec(downPointX, downPointY, downPointZ), boundingBox, 2, current, goal, visited);
        if (nodeFall != null && !visited.contains(nodeFall)) nearby.add(nodeFall);

        return nearby;
    }

    @Override
    public boolean hasGravitySnap() {
        return false;
    }

    private PNode createFly(Block.Getter getter, Point point, BoundingBox boundingBox, double cost, PNode start, Point goal, Set<PNode> closed) {
        var n = newNode(start, cost, point, goal);
        if (closed.contains(n)) return null;
        if (!canMoveTowards(getter, new Vec(start.x(), start.y(), start.z()), point, boundingBox)) return null;
        n.setType(PNode.Type.FLY);
        return n;
    }

    private PNode newNode(PNode current, double cost, Point point, Point goal) {
        tempNode.setG(current.g() + cost);
        tempNode.setH(heuristic(point, goal));
        tempNode.setPoint(point.x(), point.y(), point.z());

        var newNode = tempNode;
        tempNode = new PNode(0, 0, 0, 0, 0, PNode.Type.WALK, current);

        return newNode;
    }

    @Override
    public OptionalDouble gravitySnap(Block.Getter getter, double pointX, double pointY, double pointZ, BoundingBox boundingBox, double maxFall) {
        return OptionalDouble.of(pointY);
    }
}
